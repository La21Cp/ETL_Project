# modules/clean_data.py
from pyspark.sql.functions import regexp_replace, col

def limpiar_dataframe(dataframe, columnas_limpiar=None, columnas_convertir=None, columnas_eliminar=None):
    # Limpiar nombres de columnas eliminando espacios adicionales
    nuevos_nombres = [col.strip() for col in dataframe.columns]
    for viejo, nuevo in zip(dataframe.columns, nuevos_nombres):
        dataframe = dataframe.withColumnRenamed(viejo, nuevo)
    
    # Eliminar columnas especificadas
    if columnas_eliminar:
        dataframe = dataframe.drop(*columnas_eliminar)
    
    # Limpiar valores en columnas específicas
    if columnas_limpiar:
        for columna in columnas_limpiar:
            if columna in dataframe.columns:
                dataframe = dataframe.withColumn(columna, regexp_replace(col(columna), "[^0-9.]", ""))
    
    # Convertir columnas a tipos numéricos
    if columnas_convertir:
        for columna, tipo in columnas_convertir:
            if columna in dataframe.columns:
                dataframe = dataframe.withColumn(columna, col(columna).cast(f"{tipo}"))
    
    return dataframe