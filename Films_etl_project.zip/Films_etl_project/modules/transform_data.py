# modules/transform_data.py
from pyspark.sql import DataFrame

def calcular_peliculas_por_tienda(sdf_inventory: DataFrame):
    """
    Calcular cuántas películas fueron vendidas por cada tienda.
    """
    return sdf_inventory.groupBy("store_id").count()


from pyspark.sql.functions import avg, min, max , count , col

def calcular_estadisticas_spark(spark_df, columna):
    """
    Calcula el promedio, mínimo y máximo de una columna específica en un DataFrame de PySpark.
    
    Parámetros:
    spark_df (pyspark.sql.DataFrame): El DataFrame que contiene la columna.
    columna (str): El nombre de la columna sobre la que se desea calcular las estadísticas.
    
    Retorna:
    dict: Un diccionario con el promedio, mínimo y máximo de la columna especificada.
    """
    # Realizamos el cálculo de promedio, mínimo y máximo
    resultado = spark_df.agg(
        avg(columna).alias('promedio'),
        min(columna).alias('minimo'),
        max(columna).alias('maximo')
    ).collect()[0]  # .collect() devuelve el resultado como una lista de filas

    # Crear un diccionario con los resultados
    estadisticas = {
        "Columna": columna,
        "Promedio ": f"{resultado['promedio']:.2f}",
        " mínimo": f"{resultado['minimo']:.2f}",
        " máximo": f"{resultado['maximo']:.2f}"
    }

    # Imprimir el diccionario en la terminal
    print(estadisticas)
    
    
    
    
    
def obtener_categorias_mas_alquiladas(sdf_film_clean, sdf_inventory_clean, sdf_rental_clean):
    """
    Calcula las categorías de películas (rating) más alquiladas, teniendo en cuenta que el mismo film_id
    puede aparecer múltiples veces en el inventario.

    Parámetros:
    sdf_film_clean (DataFrame): DataFrame con la información de las películas (rating).
    sdf_inventory_clean (DataFrame): DataFrame con la información del inventario (film_id, inventory_id).
    sdf_rental_id (DataFrame): DataFrame con la información de los alquileres (inventory_id).
    
    Retorna:
    DataFrame: Un DataFrame con las categorías de películas (rating) y la cantidad de alquileres por categoría,
    ordenado de mayor a menor.
    """
    # Unir las tres tablas:
    # 1. sdf_film_clean y sdf_inventory_clean por film_id
    # 2. sdf_inventory_clean y sdf_rental_id por inventory_id
    df_completo = sdf_film_clean.join(sdf_inventory_clean, sdf_film_clean.film_id == sdf_inventory_clean.film_id) \
                                .join(sdf_rental_clean, sdf_inventory_clean.inventory_id == sdf_rental_clean.inventory_id)

    # Agrupar por la columna 'rating' y contar los alquileres por cada categoría
    categorias_alquiladas = df_completo.groupBy("rating") \
                            .agg(count("rental_id").alias("alquileres")) \
                            .orderBy(col("alquileres").desc())

    # Mostrar el resultado (si es necesario)
    categorias_alquiladas.show()

    return categorias_alquiladas


from pyspark.sql import functions as F

from pyspark.sql import functions

def obtener_peliculas_mas_alquiladas(sdf_film, sdf_inventory, sdf_rental):
    # Unir la tabla 'rental' con 'inventory' usando 'inventory_id' (rental tiene inventory_id, y inventory tiene film_id)
    rental_con_inventory = sdf_rental.join(sdf_inventory, on="inventory_id", how="inner")

    # Unir el resultado con la tabla 'film' usando 'film_id'
    rental_con_inventory_con_film = rental_con_inventory.join(sdf_film, on="film_id", how="inner")

    # Contar la cantidad de veces que cada película (film_id) ha sido alquilada
    peliculas_mas_alquiladas = rental_con_inventory_con_film.groupBy("film_id", "title") \
                                                        .agg(functions.count("rental_id").alias("alquileres")) \
                                                        .orderBy(functions.col("alquileres").desc()) \
                                                        .limit(10)  # Obtener solo las 10 películas más alquiladas

    # Mostrar el resultado con las 10 películas más alquiladas
    peliculas_mas_alquiladas.show()

    return peliculas_mas_alquiladas