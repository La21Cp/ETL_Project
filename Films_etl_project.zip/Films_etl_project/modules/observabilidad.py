import logging

# modules/observability.py
import logging

def setup_logger():
    logger = logging.getLogger("ETL_Logger")
    logger.setLevel(logging.INFO)
    
    # Crear un handler para escribir en consola
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # Formato del logger
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(formatter)
    
    # Agregar handler al logger
    logger.addHandler(console_handler)
    
    return logger