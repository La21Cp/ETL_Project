import pandas as pd

import findspark
findspark.init()

from pyspark import SparkContext, SparkConf

from pyspark.sql import SparkSession

from pyspark.sql.functions import regexp_replace, col

def leer_excel_archivo(file_path, hojas, convertir_a_spark=False):
    """
    Lee varias hojas de un archivo Excel y las devuelve como un diccionario.
    """
    datos = {}
    spark = SparkSession \
    .builder \
    .appName("Films2") \
    .config("spark.some.config.option", "some-value") \
    .getOrCreate()
    
    for hoja in hojas:
        df_pandas = pd.read_excel(file_path, sheet_name=hoja, header=0)
        if convertir_a_spark:
            datos[hoja] = spark.createDataFrame(df_pandas)
        else:
            datos[hoja] = df_pandas
    return datos