# modules/etl_pipeline.py
from modules.load_data import leer_excel_archivo
from modules.clean_data import limpiar_dataframe
from modules.transform_data import calcular_peliculas_por_tienda ,calcular_estadisticas_spark,obtener_categorias_mas_alquiladas,obtener_peliculas_mas_alquiladas
from pyspark.sql.functions import regexp_replace, col
from pyspark.sql import SparkSession#Ultimo agregado
from modules.observabilidad import setup_logger

logger = setup_logger()

def ejecutar_etl(file_path):
    
    logger.info(f"Iniciando el proceso ETL para el archivo")
    
    hojas = ['film', 'inventory', 'rental', 'customer', 'store']
    
    logger.info(f"Extrayendo datos de las hojas: {hojas}")
    
    datos = leer_excel_archivo(file_path, hojas, convertir_a_spark=True)
    
    
    sdf_film = datos['film']
    sdf_inventory = datos['inventory']
    sdf_rental = datos['rental']
    sdf_customer = datos['customer']
    sdf_store = datos['store']
    
    # Limpiar y transformar cada tabla
    logger.info("Limpiando y transformando datos de la tabla 'film'")
    sdf_film_clean = limpiar_dataframe(sdf_film, columnas_limpiar=["film_id","release_year","rental_rate","length","replacement_cost","num_voted_users"], columnas_convertir=[("film_id","int"), ("release_year","int"),("length","int"),("num_voted_users","int"),("rental_duration","int"),("rental_rate","float"), ("replacement_cost","float")], columnas_eliminar=["language_id", "original_language_id"])
    
    
    logger.info("Limpiando y transformando datos de la tabla 'inventory'")
    sdf_inventory_clean = limpiar_dataframe(sdf_inventory, columnas_limpiar=["store_id"], columnas_convertir=[("inventory_id","int"),("film_id","int"),("store_id","int")])    # Realizar análisis
    
    
    logger.info("Limpiando y transformando datos de la tabla 'rental'")
    sdf_rental_clean = limpiar_dataframe(sdf_rental, columnas_convertir=[("rental_id","int"),("inventory_id","int"),("customer_id","int"),("staff_id","int")])
    sdf_rental_clean = sdf_rental_clean.withColumnRenamed("staff_id","store_id")
    
    
    logger.info("Limpiando y transformando datos de la tabla 'customer'")
    sdf_customer_clean = limpiar_dataframe(sdf_customer, columnas_convertir=[("customer_id","int"),("store_id","int"),("active","int")], columnas_eliminar=["addres_id","customer_id_old"])
    sdf_customer_clean = sdf_customer_clean.withColumn("email", regexp_replace(col("email"), r"\\r", ""))


    logger.info("Limpiando y transformando datos de la tabla 'store'")
    sdf_store_clean = limpiar_dataframe(sdf_store,columnas_convertir=[("store_id","int")], columnas_eliminar=["address_id,manager_staff_id"])

    logger.info("Calculando el número de películas por tienda")
    peliculas_por_tienda = calcular_peliculas_por_tienda(sdf_inventory_clean)
    peliculas_por_tienda.show()
    
    
    # Calculo de metricas logger
    logger.info("Calculo de metricas de promedio en rentas y reemplazo'")
    #Estadistica de  precios de rentas tabla film
    calcular_estadisticas_spark(sdf_film_clean,"rental_rate")
    
    #Estadistica de precios de remplazo replace_cost
    calcular_estadisticas_spark(sdf_film_clean,"replacement_cost")
    
    
    #Calculo de las peliculas por categoria
    logger.info("Calculo de las peliculas por categoria'")
    obtener_categorias_mas_alquiladas(sdf_film_clean, sdf_inventory_clean, sdf_rental_clean)
    
    logger.info("Calculo de las peliculas mas alquiladas por nombre'")
    obtener_peliculas_mas_alquiladas(sdf_film_clean, sdf_inventory_clean, sdf_rental_clean)
    
    
    
    logger.info("Proceso ETL completado con éxito")
