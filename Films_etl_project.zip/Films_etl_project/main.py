# main.py
from modules.etl_pipeline import ejecutar_etl

if __name__ == "__main__":
    file_path = "data\\Films_2 (3).xlsx"
    ejecutar_etl(file_path)
